#!/bin/bash 
yum install zip -y 
zip static_files.zip * 
mv static_files.zip /amzn_batch_id_reset/